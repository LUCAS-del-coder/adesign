// esbuild configuration to handle import.meta.dirname in production
import { build } from 'esbuild';

// This file can be used to customize esbuild behavior if needed
// For now, we rely on the package.json build script

